"""Tiny web API for the order-service."""
import os

from flask import Flask, jsonify, request

from app.pricing import calculate_total

app = Flask(__name__)
VERSION = os.environ.get("APP_VERSION", "dev")


@app.get("/health")
def health():
    return jsonify(status="ok", version=VERSION)


@app.get("/total")
def total():
    try:
        cart_value = float(request.args.get("cart_value", ""))
    except ValueError:
        return jsonify(error="cart_value must be a number"), 400
    try:
        amount = calculate_total(cart_value)
    except ValueError as err:
        return jsonify(error=str(err)), 400
    return jsonify(cart_value=cart_value, total=amount, version=VERSION)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
