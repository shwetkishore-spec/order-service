"""Order pricing logic for the order-service."""

DISCOUNT_THRESHOLD = 500   # rupees
DISCOUNT_RATE = 0.10       # 10%


def calculate_total(cart_value: float) -> float:
    """Return the amount to charge, applying 10% off for carts above Rs 500."""
    if cart_value < 0:
        raise ValueError("cart_value cannot be negative")
    if cart_value > DISCOUNT_THRESHOLD:
        return round(cart_value * (1 - DISCOUNT_RATE), 2)
    return round(cart_value, 2)
